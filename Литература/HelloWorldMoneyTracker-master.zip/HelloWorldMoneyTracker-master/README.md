# HelloWorldMoneyTracker
Our first simple android app
<img src="https://github.com/netimen/HelloWorldMoneyTracker/blob/master/design.jpg" align="left" height="400" >
